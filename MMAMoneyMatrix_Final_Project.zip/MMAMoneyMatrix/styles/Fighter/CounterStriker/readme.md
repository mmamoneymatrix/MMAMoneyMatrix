# CounterStriker (Fighter)

Description for CounterStriker style.