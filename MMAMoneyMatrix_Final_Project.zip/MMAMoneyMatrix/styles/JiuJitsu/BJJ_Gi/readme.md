# BJJ_Gi (JiuJitsu)

Description for BJJ_Gi style.