# CounterPuncher (Boxer)

Description for CounterPuncher style.