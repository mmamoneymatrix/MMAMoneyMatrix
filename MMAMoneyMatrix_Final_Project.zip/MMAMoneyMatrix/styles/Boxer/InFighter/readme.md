# InFighter (Boxer)

Description for InFighter style.