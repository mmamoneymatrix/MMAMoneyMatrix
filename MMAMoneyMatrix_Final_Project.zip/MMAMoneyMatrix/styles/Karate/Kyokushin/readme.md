# Kyokushin (Karate)

Description for Kyokushin style.