# Shotokan (Karate)

Description for Shotokan style.